/* 
 *  ===================================================================
 *  Titre : Instructions.cpp
 *  Auteur : Thomas Broussard
 *  ------------------------------------------------------------------
 *  Description :
 *  Fonctions et variables permettant de communiquer avec 
 *  le serveur MQTT via un jeu d'instructions prédéfini
 * ===================================================================
 */
#include "Instructions.h"

// --------------------------------------------
// Décodage des instructions
// --------------------------------------------
void Decode_Instruction(String Instruction)
{
      String Data;
      DEBUG_PRINTLN("Instruction reçue : " + Instruction);
      
     /* =========================================
     * START
     * Autorise le programme à démarrer
     * ========================================= */
     if(Instruction == START)
     {
          callback_START();
     }
     /* =========================================
     * STOP
     * Interdit au programme de s'exécuter
     * ========================================= */
     else if(Instruction == STOP)
     {
          callback_STOP();
     }
     
     /* =========================================
     * DATA
     * Demande au client d'envoyer des données au serveur (capteurs)
     * ========================================= */
     if(Instruction == DATA)
     {
          callback_DATA();
     }

    /* =========================================
     * ONx
     * Passe le Trigger n°x à l'état ON
     * ========================================= */
    else if(Instruction.startsWith(ON))
     {
           Data = Instruction.substring(strlen(ON));
           callback_TRIGGER_ON(Data.toInt());
     }
    /* =========================================
     * OFFx
     * Passe le Trigger n°x à l'état OFF
     * ========================================= */
    else if(Instruction.startsWith(OFF))
     {
           Data = Instruction.substring(strlen(OFF));
           callback_TRIGGER_OFF(Data.toInt());
     }
    /* =========================================
     * CONNECT
     * Le serveur veut savoir si l'objet est connecté
     * ========================================= */
    else if(Instruction == CONNECT)
    {
           callback_CONNECT();
    }      
}

// ------------------------------------------------------
// Création d'un payload à partir d'un tableau de données
// ------------------------------------------------------
String Create_Payload_From_Table(String Data[], int Nb_Data)
{
  String Payload = String(Nb_Data);
  
  for(int i = 0; i < Nb_Data; i++){
      Payload+= ";" + Data[i];
  }
  return Payload;
}



