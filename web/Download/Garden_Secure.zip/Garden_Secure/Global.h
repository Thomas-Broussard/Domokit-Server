/* 
 *  ===================================================================
 *  Titre : Global.h
 *  Auteur : Thomas Broussard
 *  ------------------------------------------------------------------
 *  Description : 
 *  Permet de lier l'ensemble des librairies entre elles
 * 
 * ===================================================================
 */
 
#ifndef __GLOBAL_H__
#define __GLOBAL_H__

  // ----------------------------------------
  //          Librairies
  // ----------------------------------------
  #include "Arduino.h"
  #include <ESP8266WiFi.h>
  #include <PubSubClient.h>

  #include "DomoKit.h"
  #include "Instructions.h"
  #include "Infos_Wifi.h"
  #include "Configuration.h"

  // Fonctions associées au mode Debug
  #ifdef DEBUG
   #define DEBUG_PRINTLN(x)  Serial.println(x)
   #define DEBUG_PRINT(x)    Serial.print(x) 
  #else
   #define DEBUG_PRINTLN(x)
   #define DEBUG_PRINT(x)  
  #endif

  #ifdef ERROR_OUTPUT
    #define ERROR_OUTPUT_ON()      digitalWrite(ERROR_OUTPUT,HIGH);    
    #define ERROR_OUTPUT_OFF()     digitalWrite(ERROR_OUTPUT,HIGH);
   #else
    #define ERROR_OUTPUT_OFF()
    #define ERROR_OUTPUT_ON()
   #endif

   #ifdef WIFI_OUTPUT
    #define WIFI_OUTPUT_ON()       digitalWrite(WIFI_OUTPUT,HIGH);    
    #define WIFI_OUTPUT_OFF()      digitalWrite(WIFI_OUTPUT,HIGH); 
   #else
    #define WIFI_OUTPUT_OFF()
    #define WIFI_OUTPUT_ON()
   #endif
  // ----------------------------------------
  //          Variables
  // ----------------------------------------

  // Autorisation pour démarrer le programme
  extern bool Program_Start;
  
  // Infos sur l'appareil
  extern String Nom_Appareil;
  extern String Adresse_MAC;
  extern String ClientName;
  
  // Client MQTT
  extern PubSubClient client;
  
  // Topics MQTT
  extern String topic_connexion;
  extern String topic_instruction;
  extern String topic_donnees;
  extern String topic_interruption;
  extern String topic_connect;

  // Informations Hardware
  extern int Trigger_Pins[NB_TRIGGER];
    
  // ----------------------------------------
  // Fonctions Infos_Wifi
  // ----------------------------------------
  extern String macToStr(const uint8_t* mac);
  extern void setup_wifi(String Hostname);
  extern void setup_mqtt();
  extern void reconnect();
  extern void MQTT_Receive(char* topic, byte* payload, unsigned int length);

  // ----------------------------------------
  // Fonctions Instructions
  // ----------------------------------------
  extern void Decode_Instruction(String Instruction);
  extern void MQTT_Send(String topic,String Payload);
  extern String Create_Payload_From_Table(String Data[100], int Nb_Data);
  
  // ----------------------------------------
  // Fonctions DomoticPi
  // ----------------------------------------
  extern void setup_DomoticPi();
  extern bool loop_DomoticPi();

  // ----------------------------------------
  // Fonctions Callback 
  // ----------------------------------------
  extern void callback_START();
  extern void callback_STOP();
  extern void callback_DATA();
  extern void callback_TRIGGER_ON(int Channel);
  extern void callback_TRIGGER_OFF(int Channel);
  extern void callback_CONNECT();
  
#endif
