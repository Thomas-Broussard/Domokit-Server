
#ifndef __CONFIGURATION_H__
#define __CONFIGURATION_H__

  /* ######################################################          
   *                 DEVELOPPEMENT / DEBUG
   * ###################################################### */
  // Mode Debug (commenter pour désactiver)
  #define DEBUG

  // Pins d'informations (commenter pour désactiver)
  #define ERROR_OUTPUT   D6
  #define WIFI_OUTPUT    D5
  
  /* ######################################################          
   *                      CONNEXION WIFI
   *                    (voir Infos_Wifi.h)
   * ###################################################### */
  // Point d'accès wifi
  #define SSID_WIFI     "<DomoKit>" // A remplacer par <DomoKit>
  #define PSWD_WIFI     "domokit2018" // A remplacer par domokit
  
  // Serveur MQTT
  #define MQTT_SERVER   "192.168.100.1" // Local : 192.168.100.1 / Distant : 185.212.213.243 
  #define MQTT_PORT     1883            // Local : 1883 / Distant : 32001
  
  // Login MQTT
  #define MQTT_USER     "domokit" // A remplacer par domokit-user
  #define MQTT_PSWD     "domokit" // A remplacer par domokit-user

  // Topic principal MQTT
  #define MAIN_TOPIC    "domokit"   // A remplacer par domokit
   
  /* ######################################################          
   *                      INSTRUCTIONS
   *                  (voir Instructions.h)
   * ###################################################### */  
  // Jeu d'instructions interprétable par le client
  #define START       "START"
  #define STOP        "STOP"
  #define ON          "ON"
  #define OFF         "OFF"
  #define DATA        "DATA"
  #define CONNECT     "CONNECT"

  /* ######################################################          
   *                  CONFIGURATION DES DONNEES
   *                  (voir Programme principal)
   * ###################################################### */  
  // Nombre de données à envoyer au serveur
  #define NB_DATA     3

  // Nombre de trigger (pins pilotables) utilisables par le serveur
  #define NB_TRIGGER  0

#endif
