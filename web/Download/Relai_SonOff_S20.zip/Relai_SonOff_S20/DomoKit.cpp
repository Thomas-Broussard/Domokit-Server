/* 
 *  =============================================================================================================================================
 *  Titre : DomoticPi.cpp
 *  Auteur : Thomas Broussard
 *  ---------------------------------------------------------------------------------------------------------------------------------------------
 *  Description :
 *  Librairie permettant de construire facilement un objet connecté DomoticPi
 * =============================================================================================================================================
 */

#include "DomoKit.h"

// Variables globales échangées entre les fichiers
bool Program_Start = false;

// ----------------------------------------
// Routine d'initialisation DomoticPi
// ----------------------------------------
void setup_DomoKit(){

  // Patte indiquant si une erreur a eu lieu
  #ifdef ERROR_OUTPUT 
    pinMode(ERROR_OUTPUT , OUTPUT); digitalWrite(ERROR_OUTPUT, LOW);
  #endif

  // Témoin d'activité wifi
  #ifdef WIFI_OUTPUT
    pinMode(WIFI_OUTPUT , OUTPUT); digitalWrite(WIFI_OUTPUT, LOW);
  #endif
  
  // Liaison série (115200 bauds)
  #ifdef DEBUG
    Serial.begin(9600);
  #endif

  // Connexion au réseau wifi
  setup_wifi(Nom_Appareil);

  // Connexion au serveur mqtt
  setup_mqtt();

   // Initialisation de l'ensemble des triggers 
   #ifdef NB_TRIGGER
    if (NB_TRIGGER > 0)
    {
      for (int i = 0 ; i < NB_TRIGGER ; i++){
        pinMode(Trigger_Pins[i] , OUTPUT);
      }
    }
   #endif
}

// ----------------------------------------
// Routine de connexion
// ----------------------------------------
bool loop_DomoKit(){
  
  if (!client.connected()) {
    reconnect();
  }
  client.loop();
  // si le programme n'est pas activé, le client envoie son adresse mac et son nom au serveur
  if (Program_Start == false){
      MQTT_Send(topic_connexion,(Adresse_MAC + ";" + ClientName + ";" + NB_DATA + ";" + NB_TRIGGER));
      
      DEBUG_PRINTLN("Authentification en cours..."); 
      
      #ifdef WIFI_OUTPUT
        digitalWrite(WIFI_OUTPUT, HIGH); delay(500);digitalWrite(WIFI_OUTPUT, LOW);delay(500);
        digitalWrite(WIFI_OUTPUT, HIGH); delay(500);digitalWrite(WIFI_OUTPUT, LOW);delay(500);
        digitalWrite(WIFI_OUTPUT, HIGH); delay(500);digitalWrite(WIFI_OUTPUT, LOW);delay(500);
      #else 
        delay(3000);
      #endif
      
      return false;
  }
  else
    #ifdef WIFI_OUTPUT
      digitalWrite(WIFI_OUTPUT, HIGH);
    #endif
    return true;
}


// ------------------------------------------------------
// Envoi d'une donnée au serveur
// ------------------------------------------------------
void Send_Data(int Channel, String Data){
  // Composition du topic
  String topic = topic_donnees + "/" + Channel;

  // Envoi de la donnée
  DEBUG_PRINTLN(topic);
  DEBUG_PRINTLN(Data);
  
  MQTT_Send(topic,Data);
}

