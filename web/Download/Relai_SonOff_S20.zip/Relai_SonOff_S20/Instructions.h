/* 
 *  ===================================================================
 *  Titre : Instructions.h
 *  Auteur : Thomas Broussard
 *  ------------------------------------------------------------------
 *  Description :
 *  Fonctions et variables permettant de communiquer avec le serveur MQTT
 *  via un jeu d'instructions prédéfini
 * ===================================================================
 */
#ifndef __INSTRUCTIONS_H__
#define __INSTRUCTIONS_H__

  #include "Global.h"
  
  // ----------------------------------------
  // Fonctions
  // ----------------------------------------
  void Decode_Instruction(String Instruction);
  String Create_Payload_From_Table(String Data[], int Nb_Data);

#endif
