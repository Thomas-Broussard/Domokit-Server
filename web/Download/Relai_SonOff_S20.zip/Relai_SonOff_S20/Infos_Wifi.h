/* 
 *  ===================================================================
 *  Titre : Infos_Wifi.cpp
 *  Auteur : Thomas Broussard
 *  ------------------------------------------------------------------
 *  Description :
 *  Fonctions et variables permettant d'initialiser
 *  les connexions au point d'accès Wifi et au serveur MQTT
 * ===================================================================
 */
#ifndef __INFOS_WIFI_H__
#define __INFOS_WIFI_H__

  #include "Global.h"
  
  // ----------------------------------------
  // Fonctions
  // ----------------------------------------
  String macToStr(const uint8_t* mac);
  void setup_wifi(String Hostname);
  void setup_mqtt();
  void reconnect();
  void MQTT_Receive(char* topic, byte* payload, unsigned int length);
  void MQTT_Send(String topic, String Payload);
#endif
