/* 
 *  ===================================================================
 *  Titre : Infos_Wifi.cpp
 *  Auteur : Thomas Broussard
 *  ------------------------------------------------------------------
 *  Description :
 *  Fonctions et variables permettant d'initialiser
 *  les connexions au point d'accès Wifi et au serveur MQTT
 * ===================================================================
 */
 
#include "Infos_Wifi.h"

// ----------------------------------------
// Nom du capteur
// ----------------------------------------
String Adresse_MAC;
String ClientName;

// ------------------------------------
// Topics MQTT
// ------------------------------------
String prefix    = MAIN_TOPIC;

String topic_connexion;
String topic_instruction;
String topic_donnees;
String topic_interruption;
String topic_connect;
// ------------------------------------
// ESP 8266 
// ------------------------------------
WiFiClient espClient;
PubSubClient client(espClient);

// --------------------------------------------
// Conversion d'une @Mac en String
// --------------------------------------------
String macToStr(const uint8_t* mac)
{
  String result;
  for (int i = 0; i < 6; ++i) {
    result += String(mac[i], 16);
    if (i < 5)
      result += ':';
  }
  return result;
}


// --------------------------------------------
// Routine pour démarrer le wifi
// --------------------------------------------
void setup_wifi(String Hostname) {

  delay(10);
  
  // On masque le point d'accès wifi généré par l'ESP
  WiFi.mode(WIFI_STA);
  WiFi.hostname((char*)Hostname.c_str());
  
  delay(10);

  DEBUG_PRINTLN();
  DEBUG_PRINT("Connexion au hotspot "); DEBUG_PRINTLN(SSID_WIFI);
  DEBUG_PRINT("En tant que ");          DEBUG_PRINTLN(WiFi.hostname());
  DEBUG_PRINTLN();
  
  // Connexion au point d'accès wifi
  WiFi.begin(SSID_WIFI, PSWD_WIFI);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    DEBUG_PRINT(".");
  }
  
  DEBUG_PRINTLN();
  DEBUG_PRINTLN("Connexion au wifi réussie");
  DEBUG_PRINTLN("Adresse IP : ["); DEBUG_PRINT(WiFi.localIP()); DEBUG_PRINTLN("]");
  DEBUG_PRINTLN();
}

// --------------------------------------------
// Routine pour se connecter au serveur mqtt
// --------------------------------------------
void setup_mqtt(){
  client.setServer(MQTT_SERVER, MQTT_PORT);
  client.setCallback(MQTT_Receive);
  
  DEBUG_PRINTLN("Connexion au serveur MQTT réussie");
  
  // Obtention de l'adresse MAC du client
  uint8_t mac[6];
  WiFi.macAddress(mac);
  Adresse_MAC = macToStr(mac);

  // Génération du nom client à partir de l'adresse MAC de l'objet et de son nom
  ClientName = Nom_Appareil + '_' + Adresse_MAC;
   
  // Création des topics MQTT
  topic_instruction   = prefix + "/instruction/"  + Adresse_MAC;
  topic_donnees       = prefix + "/donnees/"      + Adresse_MAC;
  topic_interruption  = prefix + "/interruption/" + Adresse_MAC;
  topic_connexion     = prefix + "/connexion";
  topic_connect       = prefix + "/connect/"  + Adresse_MAC;
  
  // Affichage de Debug
  DEBUG_PRINTLN("Connecté en tant que " + ClientName);
  DEBUG_PRINTLN();
  DEBUG_PRINTLN("Liste des topics :");
  DEBUG_PRINTLN(topic_connexion);
  DEBUG_PRINTLN(topic_instruction);
  DEBUG_PRINTLN(topic_donnees);
  DEBUG_PRINTLN(topic_interruption);
  DEBUG_PRINTLN();
}

// --------------------------------------------
// Reconnexion au réseau wifi
// --------------------------------------------
void reconnect() {
  // Loop until we're reconnected
  while (!client.connected()) 
  {
  
    DEBUG_PRINT("Connexion au broker MQTT ");   DEBUG_PRINTLN(MQTT_SERVER);
    DEBUG_PRINT("En tant que ");                DEBUG_PRINTLN(ClientName);
    
    // Connexion
    if (client.connect((char*) ClientName.c_str() , (char*)MQTT_USER , (char*)MQTT_PSWD))
    {
      #ifdef ERROR_OUTPUT
        digitalWrite(ERROR_OUTPUT, LOW);
      #endif
      DEBUG_PRINTLN("Connexion au broker MQTT réussie");
      
      // inscription au topic d'instruction
      client.subscribe((char*)topic_instruction.c_str());
    } 
    
    else 
    {
      DEBUG_PRINT("Echec de connexion au broker MQTT ! rc="); DEBUG_PRINTLN(client.state());
      DEBUG_PRINTLN("Nouvelle tentative dans 5 secondes...");
      
      #ifdef ERROR_OUTPUT
        digitalWrite(ERROR_OUTPUT, HIGH); delay(500);digitalWrite(ERROR_OUTPUT, LOW);delay(500);
        digitalWrite(ERROR_OUTPUT, HIGH); delay(500);digitalWrite(ERROR_OUTPUT, LOW);delay(500);
        digitalWrite(ERROR_OUTPUT, HIGH); delay(500);digitalWrite(ERROR_OUTPUT, LOW);delay(500);
        digitalWrite(ERROR_OUTPUT, HIGH); delay(500);digitalWrite(ERROR_OUTPUT, LOW);delay(500);
        digitalWrite(ERROR_OUTPUT, HIGH); delay(500);digitalWrite(ERROR_OUTPUT, LOW);delay(500);
      #else 
        delay(5000);
      #endif
    }
  }
}



// --------------------------------------------
// Réception d'un message MQTT
// --------------------------------------------
void MQTT_Receive(char* topic, byte* payload, unsigned int length) 
{
  char str_payload[512];
  memset(str_payload, 0, sizeof(str_payload));

  // Réception des données
  for (int i = 0; i < length; i++)
    str_payload[i] = payload[i];

  // Affichage au terminal
  DEBUG_PRINTLN();
  DEBUG_PRINT("Topic de réception :["); DEBUG_PRINT(topic); DEBUG_PRINTLN("] ");
  DEBUG_PRINT("Payload reçu [");DEBUG_PRINT(str_payload);DEBUG_PRINTLN("] ");

  // Décodage de l'instruction
  Decode_Instruction(String(str_payload));
}

// --------------------------------------------
// Envoi des données sur MQTT
// --------------------------------------------
void MQTT_Send(String topic, String Payload)
{
  client.publish((char*)topic.c_str(),(char*)Payload.c_str());
  
  // Affichage de debug
  DEBUG_PRINT("\nPayload envoyé : [");
  DEBUG_PRINT(Payload);
  DEBUG_PRINTLN("]");
}

