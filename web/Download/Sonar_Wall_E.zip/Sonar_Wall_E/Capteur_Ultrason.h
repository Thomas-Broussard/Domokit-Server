/*
 PubSubClient.h - A simple client for MQTT.
  Nick O'Leary
  http://knolleary.net
*/

#ifndef Capteur_Ultrason_h
#define Capteur_Ultrason_h

#include <Arduino.h>

class Capteur_Ultrason {
private:
  int Trigger_Pin;
  int Echo_Pin;
  
  int Portee_cm;
  int Distance_cm;
  
  boolean Detect;
  boolean Detect_Stable;
  
public:
   // Constructeur
   Capteur_Ultrason(int Trigger_Pin, int Echo_Pin);

   // Getters
   boolean getDetection();
   boolean getDetection_Stable(int nb_mesures, int temps_mesure);
   int getDistance_cm();
   int getPortee_cm(); 
   
   // Setters
   void setPortee_cm(int Valeur);

   
   // Méthodes
   
   // Renvoie la distance entre l'objet et le capteur
   void Ultrason_Read();

   // Réalise une détection sur plusieurs points, pour s'assurer d'une bonne détection
   void Ultrason_Detect_Stable(int nb_mesures, int temps_mesure);

   // Renvoie 1 si un objet est détecté, 0 sinon
   void Ultrason_Detect();
};


#endif
