/*
  PubSubClient.cpp - A simple client for MQTT.
  Nick O'Leary
  http://knolleary.net
*/

#include "Capteur_Ultrason.h"
#include "Arduino.h"

// Constructeur
Capteur_Ultrason::Capteur_Ultrason(int Trigger_Pin, int Echo_Pin) {
    this->Trigger_Pin = Trigger_Pin;
    this->Echo_Pin = Echo_Pin;

    this->Portee_cm = 0;
    this->Distance_cm = 0;

    this->Detect = false;
    this->Detect_Stable = false;
}

// Getters
boolean Capteur_Ultrason::getDetection() {
    this->Ultrason_Detect();
    return this->Detect;
}

boolean Capteur_Ultrason::getDetection_Stable(int nb_mesures, int temps_mesure) {
    this->Ultrason_Detect_Stable(nb_mesures,temps_mesure);
    return this->Detect_Stable;
}

int Capteur_Ultrason::getDistance_cm() {
    this->Ultrason_Read();
    return this->Distance_cm;
}

int Capteur_Ultrason::getPortee_cm() {
    return this->Portee_cm;
}

// Setters
void Capteur_Ultrason::setPortee_cm(int Valeur) {
    this->Portee_cm = Valeur;
}

// Methodes

void Capteur_Ultrason::Ultrason_Read(){
  int duration;
   
  // Génération d'une impulsion sur l'émetteur
  digitalWrite(this->Trigger_Pin, LOW);
  delayMicroseconds(2);
  digitalWrite(this->Trigger_Pin, HIGH);
  delayMicroseconds(10);
  digitalWrite(this->Trigger_Pin, LOW);

  // Réception d'une impulsion sur le récepteur
  duration = pulseIn(this->Echo_Pin,HIGH);
 
  // conversion du temps (entre l'émission et la réception) en distance (en centimètres)
  this->Distance_cm = duration / 29.1 / 2 ;
}


void Capteur_Ultrason::Ultrason_Detect(){
    this->Ultrason_Read();
    this->Detect = (this->Distance_cm < this->Portee_cm)? true:false ;
}


void Capteur_Ultrason::Ultrason_Detect_Stable(int nb_mesures, int temps_mesure){
  boolean Result = true;
  int Detection;
  
  for(int i = 0; i  < nb_mesures ; i ++)
  {
    this->Ultrason_Detect();
    if (this->Detect == false)
     {
        Result = false;
     }
     delay(temps_mesure);
  }
  this->Detect_Stable = Result;
}


