########################################################################################
Produit : D�tecteur de flammes
Date 	: 2018 / 2019
Auteur	: Domokit
----------------------------------------------------------------------------------------
Description :Ce package de ressources vous permettra de fabriquer un d�tecteur de flammes 


----------------------------------------------------------------------------------------
Contenu du package : 

- Documentation/
	- Detecteur_de_flammes_01.pdf : Documentation sur la conception de l'objet

- PCB/
	- Fichiers permettant de fabriquer la carte �lectronique d�di�e
- Boitier/
	- Fichiers permettant de fabriquer le bo�tier de l'objet , via l'impression 3D

- Code/ 
	- Programmation de l'objet (sous PlatformIO)

----------------------------------------------------------------------------------------
Credits	:
Antoine Choplin
########################################################################################