/* 
 *  ===================================================================
 *  Titre : Mesure_Conso.h
 *  Auteur : Thomas Broussard
 *  ------------------------------------------------------------------
 *  Description :
 *  Fonctions permettant de mesurer la consommation électrique 
 *  Grâce à des capteurs de courant
 * ===================================================================
 */
#ifndef __MESURE_CONSO_H__
#define __MESURE_CONSO_H__

  #include "Arduino.h"
  
  // Fonctions
  void init_Capteurs_Courant(int pin[], int NB_Pins);
  float Courant_Amplitude(byte pin);
  float Courant_Efficace(byte pin);
  float Consommation_Instantanee(byte pin);


#endif
