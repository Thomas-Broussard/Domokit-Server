/* 
 *  ===================================================================
 *  Titre : DHT22.h
 *  Auteur : Thomas Broussard
 *  ------------------------------------------------------------------
 *  Description :
 *  Fonctions permettant de gérer simplement le DHT22
 *  (Capteur de température et d'humidité)
 * ===================================================================
 */
#ifndef __DHT22_H__
#define __DHT22_H__


  // Pins du DHT22 ( à configurer)
  #define ENABLE_DHT    7      // Patte d'alimentation du DHT ( qui sera géré par l'arduino, pour économiser de l'énergie )
  #define DHTPIN        6      // Signal du DHT22
  #define DHTTYPE       DHT22   // Référence du capteur (DHT 22)

  
  // ----------------------------------------
  // Fonctions
  // ----------------------------------------
  String read_DHT22_temperature();
  String read_DHT22_humidity();
  void enable_DHT22();
  void disable_DHT22(); 

#endif
