
#include "DHT.h"
#include "DHT22.h"


// ------------------------------------
// Capteur de Température/Humidité DHT22 
// ------------------------------------
DHT dht(DHTPIN, DHTTYPE);
int cpt_Error;

// Fonctions DHT 22

// ----------------------------------------
// Activation du capteur
// ----------------------------------------
void enable_DHT22(){
  #ifdef ENABLE_DHT
    digitalWrite(ENABLE_DHT,HIGH);
  #endif
  delay(1000);
}

// ----------------------------------------
// Désactivation du capteur
// ----------------------------------------
void disable_DHT22(){
  #ifdef ENABLE_DHT
    digitalWrite(ENABLE_DHT,LOW);
  #endif
}

// ----------------------------------------
// Lecture de la température (en degrés Celsius)
// Renvoie le résultat dans un objet String
// ----------------------------------------
String read_DHT22_temperature() {
  
    int cpt_error = 0;
    float temperature = dht.readTemperature();
  
    // On vérifie qu'on a bien reçu quelque chose
    if (isnan(temperature)) 
    {
      while (isnan(temperature))
      {
        //Serial.println("Failed to read temperature from DHT sensor!");
        digitalWrite(ENABLE_DHT,HIGH);
        delay(1000);
        cpt_Error++;
        if (cpt_Error > 5)
        {
          Serial.println("Error on DHT sensor. Please check your program and your hardware config.");
          
          cpt_Error = 0;
          return "0";
        }
        temperature = dht.readTemperature();
      }
      
    }
    else
    {
        cpt_Error = 0;
        
        DEBUG_PRINTLN(temperature);
        String Result = String(temperature)  + "°C";
        return Result;
    }
}


// ----------------------------------------
// Lecture de l'humidité (en %)
// Renvoie le résultat dans un objet String
// ----------------------------------------
String read_DHT22_humidity() {
  
    int cpt_error = 0;
    float humidite = dht.readHumidity();
  
    // On vérifie qu'on a bien reçu quelque chose
    if (isnan(humidite)) 
    {
      while (isnan(humidite))
      {
        //Serial.println("Failed to read humidity from DHT sensor!");
        digitalWrite(ENABLE_DHT,HIGH);
        delay(1000);
        cpt_Error++;
        if (cpt_Error > 5)
        {
          Serial.println("Error on DHT sensor. Please check your program and your hardware config.");
          
          cpt_Error = 0;
          return "0";
        }
        humidite = dht.readHumidity();
      }
      
    }
    else
    {
        cpt_Error = 0;
        String Result = String(humidite) + "%";
        return Result;
    }
}


