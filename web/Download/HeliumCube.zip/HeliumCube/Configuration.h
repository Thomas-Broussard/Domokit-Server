#ifndef __CONFIGURATION_H__
#define __CONFIGURATION_H__

  /* ######################################################          
   *                 DEVELOPPEMENT / DEBUG_PRGM
   * ###################################################### */
  // Mode DEBUG_PRGM (commenter pour désactiver)
  #define DEBUG_PRGM

  // Pins d'informations (commenter pour désactiver)
  //#define ERROR_OUTPUT   6
  #define CONNECTIVITY_OUTPUT    12
  
  /* ######################################################          
   *                      CONNEXION HELIUM
   *                    (voir Infos_Wifi.h)
   * ###################################################### */
  #define DEVICE_TYPE "helium"
   
  // Channel Helium utilisé 
  #define CHANNEL_NAME "Helium MQTT"

  // Adresse MAC du module Atom
  #define MAC_ATOM  "6081f9fffe00094f"
   
  /* ######################################################          
   *                      INSTRUCTIONS
   *                  (voir Instructions.h)
   * ###################################################### */  
  // Jeu d'instructions interprétable par le client
  #define START       "START"
  #define STOP        "STOP"
  #define ON          "ON"
  #define OFF         "OFF"
  #define DATA        "DATA"
  #define CONNECT     "CONNECT"

  /* ######################################################          
   *                  CONFIGURATION DES DONNEES
   *                  (voir Programme principal)
   * ###################################################### */  
  // Nombre de données à envoyer au serveur
  #define NB_DATA     4

  // Nombre de trigger (pins pilotables) utilisables par le serveur
  #define NB_TRIGGER  4

#endif
