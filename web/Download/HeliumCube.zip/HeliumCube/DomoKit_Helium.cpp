/* 
 *  =============================================================================================================================================
 *  Titre : DomoKit_Helium.cpp
 *  Auteur : Thomas Broussard
 *  ---------------------------------------------------------------------------------------------------------------------------------------------
 *  Description :
 *  Librairie permettant de construire facilement un objet connecté DomoKit via Helium IoT
 * =============================================================================================================================================
 */

#include "DomoKit_Helium.h"

#include "Board.h"
#include "Helium.h"
#include "HeliumUtil.h"

// Variables Helium
Helium  helium(&atom_serial);
Channel channel(&helium);

// Variables globales échangées entre les fichiers
String topic_connexion;
String topic_instruction;
String topic_donnees;
String topic_interruption;
String topic_connect;
String Adresse_MAC = MAC_ATOM;

bool Program_Start = false;

// ----------------------------------------
// Routine d'initialisation DomoticPi
// ----------------------------------------
void setup_Helium(){

  // Création des topics MQTT
  String prefix = "domokit";
  topic_instruction   = prefix + "/instruction/"  + Adresse_MAC;
  topic_donnees       = prefix + "/donnees/"      + Adresse_MAC;
  topic_interruption  = prefix + "/interruption/" + Adresse_MAC;
  topic_connexion     = prefix + "/connexion";
  topic_connect       = prefix + "/connect/"  + Adresse_MAC;
  
  // Patte indiquant si une erreur a eu lieu
  #ifdef ERROR_OUTPUT 
    pinMode(ERROR_OUTPUT , OUTPUT); digitalWrite(ERROR_OUTPUT, LOW);
  #endif

  // Témoin d'activité
  #ifdef CONNECTIVITY_OUTPUT
    pinMode(CONNECTIVITY_OUTPUT , OUTPUT); digitalWrite(CONNECTIVITY_OUTPUT, LOW);
  #endif
  
  // Liaison série (9600 bauds)
  #ifdef DEBUG_PRGM
    Serial.begin(9600);
  #endif

  // --------------------------
  // Connexion Helium
  // --------------------------
  // Vitesse de communication (voir Board.h)
  helium.begin(HELIUM_BAUD_RATE);

  // Connexion du module atom au réseau Helium
  helium_connect(&helium);
  
  // Connexion au Channel défini (voir Configuration.h)
  channel_create(&channel, CHANNEL_NAME);


  // --------------------------
  //  Initialisation hardware
  // --------------------------  
  
  // Initialisation de l'ensemble des triggers 
  #ifdef NB_TRIGGER
    if (NB_TRIGGER > 0)
    {
      for (int i = 0 ; i < NB_TRIGGER ; i++){
        pinMode(Trigger_Pins[i] , OUTPUT);
      }
    }
  #endif
}

// ----------------------------------------
// Routine de connexion
// ----------------------------------------
bool loop_Helium(String *Data_From_Helium){
  String Buffer_Data;
  
  if (Receive_Data(&Buffer_Data) == true){
    *Data_From_Helium = Buffer_Data;
      
    //DEBUG_PRINT("Data recue : ");
    //DEBUG_PRINTLN (*Data_From_Helium);
    
    // si le programme n'est pas activé, le client envoie son adresse mac et son nom au serveur
    if (Program_Start == false){
        String Trame = Adresse_MAC + ";" + Nom_Appareil + ";" + NB_DATA + ";" + NB_TRIGGER + ';' + DEVICE_TYPE;
  
        //DEBUG_PRINTLN(Trame);
        Helium_MQTT_Send(topic_connexion,Trame);
        
        DEBUG_PRINTLN("Authentification en cours..."); 
        
        #ifdef CONNECTIVITY_OUTPUT
          digitalWrite(CONNECTIVITY_OUTPUT, HIGH); delay(500);digitalWrite(CONNECTIVITY_OUTPUT, LOW);delay(500);
          digitalWrite(CONNECTIVITY_OUTPUT, HIGH); delay(500);digitalWrite(CONNECTIVITY_OUTPUT, LOW);delay(500);
          digitalWrite(CONNECTIVITY_OUTPUT, HIGH); delay(500);digitalWrite(CONNECTIVITY_OUTPUT, LOW);delay(500);
        #else 
          delay(3000);
        #endif
        
        return false;
    }
    else
    {
      #ifdef CONNECTIVITY_OUTPUT
        digitalWrite(CONNECTIVITY_OUTPUT, HIGH);
      #endif
    }
  }
  else{
    *Data_From_Helium = "";
  }
  return true;
}


// ------------------------------------------------------
// Envoi d'une donnée au serveur Helium MQTT
// ------------------------------------------------------

void Helium_MQTT_Send(String topic, String Payload){
  String Trame = topic + "|" + Payload; // On 'simule' le topic en le faisant passer dans le payload? 

  channel_send(&channel, CHANNEL_NAME, (char*)Trame.c_str(), strlen((char*)Trame.c_str()));
}

void Helium_Send_Data(int num_data, String Data){

  String Trame = "DATA|" + String(num_data) + "|" + Data;
  channel_send(&channel, CHANNEL_NAME, (char*)Trame.c_str(), strlen((char*)Trame.c_str()));
}



bool Receive_Data(String *Data_From_Helium){
  
      // Create a buffer of the maximum Helium network packet size
    char   data[HELIUM_MAX_DATA_SIZE];
    size_t data_used;
    bool state;
    // Call the poll utility function below which pings the network to
    // ask for data.
    state = channel_poll(data, HELIUM_MAX_DATA_SIZE, &data_used);
    
    // Convert to a printable string
    data[data_used] = '\0';
    if ((data_used > 0) && state == true)
    {
        //DEBUG_PRINT("Data - ");
        //DEBUG_PRINTLN(data);
        
        *Data_From_Helium = String(data);
        Decode_Instruction(data);
        return true;
    }
    return false;
}


// ---------------------------------------------------------
//        Scrutation des données sur le channel Helium
// ---------------------------------------------------------
bool channel_poll(void * data, size_t len, size_t * used)
{
    int status;
        DEBUG_PRINT(".");
        // Poll the channel for some data for some time
        status = channel.poll_data(data, len, used);
        
        if (report_status(status) == helium_status_OK){
            return true;
        }
        else
          return false;
}
