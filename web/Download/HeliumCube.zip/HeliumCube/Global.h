/* 
 *  ===================================================================
 *  Titre : Global.h
 *  Auteur : Thomas Broussard
 *  ------------------------------------------------------------------
 *  Description : 
 *  Permet de lier l'ensemble des librairies entre elles
 * 
 * ===================================================================
 */
 
#ifndef __GLOBAL_H__
#define __GLOBAL_H__

  // ----------------------------------------
  //          Librairies
  // ----------------------------------------
  #include "Arduino.h"
  
  #include "DomoKit_Helium.h"
  #include "Instructions.h"
  #include "Configuration.h"

  // Fonctions associées au mode DEBUG_PRGM
  #ifdef DEBUG_PRGM
   #define DEBUG_PRINTLN(x)  Serial.println(x)
   #define DEBUG_PRINT(x)    Serial.print(x)
  #else
   #define DEBUG_PRINTLN(x)
   #define DEBUG_PRINT(x)  
  #endif
  // ----------------------------------------
  //          Variables
  // ----------------------------------------

  // Autorisation pour démarrer le programme
  extern bool Program_Start;
  
  // Infos sur l'appareil
  extern String Nom_Appareil;
  extern String Adresse_MAC;
  extern String ClientName;
  
  // Topics MQTT
  extern String topic_connexion;
  extern String topic_instruction;
  extern String topic_donnees;
  extern String topic_interruption;
  extern String topic_connect;

  // Informations Hardware
  extern int Trigger_Pins[NB_TRIGGER];
    
  // ----------------------------------------
  // Fonctions Instructions
  // ----------------------------------------
  extern void Decode_Instruction(String Instruction);
  extern String Create_Payload_From_Table(String Data[100], int Nb_Data);
  
  // ----------------------------------------
  // Fonctions Callback 
  // ----------------------------------------
  extern void callback_START();
  extern void callback_STOP();
  extern void callback_DATA();
  extern void callback_TRIGGER_ON(int Channel);
  extern void callback_TRIGGER_OFF(int Channel);
  extern void callback_CONNECT();
  
#endif
