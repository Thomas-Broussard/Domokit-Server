/* 
 *  =============================================================================================================================================
 *  Titre : DomoKit_Helium.h
 *  Auteur : Thomas Broussard
 *  ---------------------------------------------------------------------------------------------------------------------------------------------
 *  Description :
 *  Librairie permettant de construire facilement un objet connecté DomoKit via Helium IoT
 * =============================================================================================================================================
 */
 
#ifndef __DOMOKIT_H__
#define __DOMOKIT_H__ 

  #include "Global.h"

  // ----------------------------------------
  // Fonctions
  // ----------------------------------------
  void setup_Helium();
  bool loop_Helium(String *Data_From_Helium);


  bool Receive_Data(String *Data_From_Helium);

  void Helium_MQTT_Send(String topic, String Payload);
  void Helium_Send_Data(int num_data,String Data);

  bool channel_poll(void * data, size_t len, size_t * used);

#endif
