
#include "Mesure_Conso.h"

    void init_Capteurs_Courant(int pin[], int NB_Pins)
    {
      for (int i = 0; i < NB_Pins; i++){
        pinMode(pin[i],INPUT);
      }
    }


    /*Function: Sample for 1000ms and get the maximum value from the SIG pin*/
    int getMaxValue(byte pin)
    {
        int sensorValue;             //value read from the sensor
        int sensorMax = 0;
        uint32_t start_time = millis();
        while((millis()-start_time) < 1000)//sample for 1000ms
        {
            sensorValue = analogRead(pin);
            if (sensorValue > sensorMax) 
            {
                /*record the maximum sensor value*/
                sensorMax = sensorValue;
            }
        }
        return sensorMax;
    }

    // Fonction : calcul de la consommation (approximative)
    float Consommation_Instantanee(byte pin){
        return 230 * (Courant_Efficace(pin) / 1000);
    }

    
    // Fonction : calcul du courant efficace (en mA)
    float Courant_Efficace(byte pin){
        return Courant_Amplitude(pin)/1.414;  //minimum_current=1/1024*5/800*2000000/1.414=8.6(mA) 
    }

    
    // Fonction : calcul du courant en amplitude
    float Courant_Amplitude(byte pin){
        float amplitude_current;               //amplitude current
        float effective_value;       //effective current 
        int sensor_max;
        
        sensor_max = getMaxValue(pin);

        // Calcul
        //the VCC on the Grove interface of the sensor is 5v
        amplitude_current=(float)sensor_max/1024*5/800*2000000;

        return amplitude_current;

    }


